import csv

new_employee_data = []
csvFile = '03-Python/Extra_Content/Stu_Email/Resources/employees.csv'
with open(csvFile, 'r') as csvf:
    reader = csv.reader(csvf, delimiter=",")
    next(reader)
    for record in reader:
        new_employee_data.append({'first':record[0], 'last':record[1], 'ssn':record[2],'email':f"{record[0]}.{record[1]}@example.com"})
print(new_employee_data)


with open('03-Python/Extra_Content/Stu_Email/Solved/newEmployees.csv','w') as outf:
    writer = csv.DictWriter(outf, fieldnames=new_employee_data[0].keys())
    writer.writeheader()

    writer.writerows(new_employee_data)
