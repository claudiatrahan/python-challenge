# Python

## Key activities from the week

### Activity - Rock, Paper, Scissors, Shoot!

Use Python to build a command line game where the user competes against their computer in rock, paper, scissors.
[Watch the Video](https://youtu.be/TjWOZDY00WA)

### Activity - Read Netflix

Use Python to create a command line tool to search through a CSV file for a user inputted show or movie.
[Watch the Video](https://youtu.be/Y3TRABzAfho)

### Activity - Wrestling with Functions

Use Python to create a command line tool that looks up the statistics for professional wrestlers.
[Watch the Video](https://youtu.be/Logbtv4oQlc)
