import csv
netflix_file ='netflix_ratings.csv'
search_term = input("What show or movie are you looking for? ")
with open(netflix_file, 'r') as nf:
    #data = [d.split(",") for d in nf.read().split("\n")]
    csvreader = csv.reader(nf, delimiter=',')
    for row in data:
        #print(row)
        if search_term in row[0]:
            print(f"{row[0]} is rated {row[1]} with a viewer rating of {row[5]}")
            break
    nf.close()