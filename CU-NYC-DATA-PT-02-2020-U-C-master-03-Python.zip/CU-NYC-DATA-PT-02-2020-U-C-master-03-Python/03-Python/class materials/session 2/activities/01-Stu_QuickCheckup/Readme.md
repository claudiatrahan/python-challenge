# Quick Check-Up!

## Instructions

* Create a simple Python command line application. Upon running, the application should:

  * Print "Hello User!"

  * Then ask: "What is your name? "

  * Then respond: "Hello &lt;user's name>"

  * Then ask: "What is your age? "

  * Then respond: "Awww... you're just a baby!" or "Ah... A well traveled soul are ye." depending on the user's age.

## Hints

* Remember to cast!
