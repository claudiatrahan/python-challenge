# Everyone Do Activity
