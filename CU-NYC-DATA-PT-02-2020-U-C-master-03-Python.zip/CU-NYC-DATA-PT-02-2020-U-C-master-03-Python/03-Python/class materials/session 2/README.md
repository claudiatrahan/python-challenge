Unit 03 - Session 2:
* [Class Recording (Mon-Wed-Sat class, no audio)](https://codingbootcamp.hosted.panopto.com/Panopto/Pages/Viewer.aspx?id=9d639de4-6323-4796-989c-ab69014209c7)
* Class Recording (Tue-Thu-Sat class)
    * [Part 1](https://codingbootcamp.hosted.panopto.com/Panopto/Pages/Viewer.aspx?id=8db1690f-3f70-4f71-8aaf-ab6900f8215f)
    * [Part 2](https://codingbootcamp.hosted.panopto.com/Panopto/Pages/Viewer.aspx?id=81705318-2775-475e-81c5-ab6901237ce5)
